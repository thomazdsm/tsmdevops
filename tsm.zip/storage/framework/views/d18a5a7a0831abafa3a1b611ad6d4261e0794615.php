<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, maximum-scale=1">
    <title>TSM - Web Developer</title>
    <link rel="icon" href="<?php echo e(asset('img/logo_circle_bgwhite.png')); ?>" type="image/png">
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('js/fancybox/jquery.fancybox.css')); ?>" type="text/css" media="screen" />
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" type="text/css">

    <link href="<?php echo e(asset('css/animate.css')); ?>" rel="stylesheet" type="text/css">

    <script src="https://kit.fontawesome.com/4d3192896f.js" crossorigin="anonymous"></script>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>

<?php echo $__env->yieldContent('content'); ?>

<!--[if lt IE 9]>
<script src="<?php echo e(asset('js/respond-1.1.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/html5shiv.js')); ?>"></script>
<script src="<?php echo e(asset('js/html5element.js')); ?>"></script>
<![endif]-->
<script type="text/javascript" src="<?php echo e(asset('js/jquery-1.11.0.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery-scrolltofixed.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.nav.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.easing.1.3.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.isotope.js')); ?>"></script>
<script src="<?php echo e(asset('js/fancybox/jquery.fancybox.pack.js')); ?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo e(asset('js/wow.js')); ?>"></script>
<script src="<?php echo e(asset('contact/jqBootstrapValidation.js')); ?>"></script>
<script src="<?php echo e(asset('contact/contact_me.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('js/custom.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/thomaz/Projects/TSM/tsmsys/resources/views/layout/main.blade.php ENDPATH**/ ?>